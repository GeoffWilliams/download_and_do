$message = "testzip OK"
write-host $message
Add-Content c:\testzip.txt $message