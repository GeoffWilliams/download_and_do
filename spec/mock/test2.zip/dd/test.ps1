$message = "testzip2 OK"
write-host $message
Add-Content c:\testzip2.txt $message